import boto3

def handler(event, context):
    ssm = boto3.client('ssm')
    cloudfront = boto3.client('cloudfront')

    parameter = ssm.get_parameter(Name='/cloudfront/distributionId', WithDecryption=True)
    distribution_id = parameter['Parameter']['Value']

    invalidation = cloudfront.create_invalidation(
        DistributionId=distribution_id,
        InvalidationBatch={
            'Paths': {
                'Quantity': 1,
                'Items': ['/*']
            },
            'CallerReference': 'some-unique-string'
        }
    )
    return invalidation
