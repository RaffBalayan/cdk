from aws_cdk import aws_lambda as _lambda, aws_s3 as s3, Stack
from constructs import Construct
from aws_cdk.aws_iam import PolicyStatement
from aws_cdk.aws_lambda_event_sources import S3EventSource

from aws_cdk.aws_cloudfront import IDistribution  # Assuming CloudFront is used elsewhere

class LambdaStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, s3bucket_name: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Create or reference an existing S3 bucket by name
        bucket = s3.Bucket.from_bucket_name(self, "S3Bucket", s3bucket_name)

        # Define the Lambda function
        lambda_function = _lambda.Function(
            self, "CloudFrontInvalidationLambda",
            runtime=_lambda.Runtime.PYTHON_3_8,
            handler="lambda_function.lambda_handler",  # Ensure the handler matches your Lambda's file and function name
            code=_lambda.Code.from_asset("Lambda/aswl.zip"),
        )

        # Adding CloudFront invalidation permissions to the Lambda function's IAM role
        # Ensure you replace 'self.cdn_id.distribution_id' with the actual CloudFront distribution ID
        # or pass it as an argument to this constructor if needed.
        lambda_function.add_to_role_policy(
            PolicyStatement(
                actions=["cloudfront:CreateInvalidation"],
                resources=["arn:aws:cloudfront:::distribution/YOUR_DISTRIBUTION_ID_HERE"],  # Placeholder for actual ID
            )
        )

        # Add S3 event source to the Lambda function
        lambda_function.add_event_source(
            S3EventSource(
                bucket,
                events=[s3.EventType.OBJECT_CREATED, s3.EventType.OBJECT_REMOVED],
                filters=[s3.NotificationKeyFilter(prefix="subdir/")]
            )
        )
